--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 9.6.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.item_dimensions DROP CONSTRAINT fksnh7d3p4udcppsfspjhsbta6q;
ALTER TABLE ONLY public.facility DROP CONSTRAINT fkrf62o3y7km7j0v3v3axinjt0v;
ALTER TABLE ONLY public.facility_facility_groups DROP CONSTRAINT fko4fakdwhwkcsje3p6icvgj3qr;
ALTER TABLE ONLY public.data_element_translations DROP CONSTRAINT fkmsvxxu81ayetxxwryvyd18l7o;
ALTER TABLE ONLY public.rmnch DROP CONSTRAINT fkmen00wrqnjf8e6dm8r3quwu4g;
ALTER TABLE ONLY public.facility_group_facilities DROP CONSTRAINT fklwwtfhcmvqa3v7xursbgsua61;
ALTER TABLE ONLY public.boundary DROP CONSTRAINT fklvt5hl8xv3jbl8kd7y1jd3yxv;
ALTER TABLE ONLY public.facility_group_facilities DROP CONSTRAINT fkl3tirh1uljkf3xhrf2j4puqje;
ALTER TABLE ONLY public.rmnch DROP CONSTRAINT fkkw8h9d9wcsxnomq2eoawxqkt9;
ALTER TABLE ONLY public.item_dimensions DROP CONSTRAINT fkkulucw5lwr46hkysg5l9wlxn2;
ALTER TABLE ONLY public.opddiagnostic DROP CONSTRAINT fki4gkh4hr3jcikll8vxahc6l7e;
ALTER TABLE ONLY public.facility DROP CONSTRAINT fkf8c50o6a6erfkx1hj3i8ba8sk;
ALTER TABLE ONLY public.service_area_population DROP CONSTRAINT fkecnnrgvhq7lk2ca2bmlbl9cer;
ALTER TABLE ONLY public.facility_group DROP CONSTRAINT fke8jxd3iytlrbitpxhfg8p79x7;
ALTER TABLE ONLY public.dimension_items DROP CONSTRAINT fke1a11lrwnmr0vjk6h5oopk75f;
ALTER TABLE ONLY public.data_element DROP CONSTRAINT fkdx8fglnnrtktmbydu7rclq3ve;
ALTER TABLE ONLY public.facility DROP CONSTRAINT fkdet2sgl9my09fk9ln00lbdes7;
ALTER TABLE ONLY public.boundary DROP CONSTRAINT fkaimesq4gtk0iuawas0vqr6rhn;
ALTER TABLE ONLY public.opddiagnostic DROP CONSTRAINT fk9apomeehpcrljyg2g5qc0mndu;
ALTER TABLE ONLY public.facility DROP CONSTRAINT fk8j57byit1jvb12yh4fg0yr5ks;
ALTER TABLE ONLY public.opddiagnostic DROP CONSTRAINT fk8ca17o9vx5wbhi6kpiwt3088q;
ALTER TABLE ONLY public.dimension_items DROP CONSTRAINT fk72sdctk51y84wcqntmjfdlpe9;
ALTER TABLE ONLY public.service_area_population DROP CONSTRAINT fk6dyn82rhv6lsxm5qu7ov8bqgu;
ALTER TABLE ONLY public.facility DROP CONSTRAINT fk5wog9901mp0tqel6i1akhwtk;
ALTER TABLE ONLY public.facility_facility_groups DROP CONSTRAINT fk2weac2drtkoy9n5os5wputc4q;
ALTER TABLE ONLY public.service_area_population DROP CONSTRAINT fk2v9tam2oiy4qe75ekv8ms17aa;
ALTER TABLE ONLY public.data_element_translations DROP CONSTRAINT fk2dw0wq479f3bdsbuhb5hfq231;
ALTER TABLE ONLY public.data_element_translations DROP CONSTRAINT uk_gb0cioki60jj0og226wg818d6;
ALTER TABLE ONLY public.translation DROP CONSTRAINT translation_pkey;
ALTER TABLE ONLY public.service_area_population DROP CONSTRAINT service_area_population_pkey;
ALTER TABLE ONLY public.rmnchstats DROP CONSTRAINT rmnchstats_pkey;
ALTER TABLE ONLY public.rmnch DROP CONSTRAINT rmnch_pkey;
ALTER TABLE ONLY public.databasechangeloglock DROP CONSTRAINT pk_databasechangeloglock;
ALTER TABLE ONLY public.opddiagnostic DROP CONSTRAINT opddiagnostic_pkey;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_pkey;
ALTER TABLE ONLY public.facility DROP CONSTRAINT facility_pkey;
ALTER TABLE ONLY public.facility_group DROP CONSTRAINT facility_group_pkey;
ALTER TABLE ONLY public.dimension DROP CONSTRAINT dimension_pkey;
ALTER TABLE ONLY public.diagnostic DROP CONSTRAINT diagnostic_pkey;
ALTER TABLE ONLY public.data_element DROP CONSTRAINT data_element_pkey;
ALTER TABLE ONLY public.data_element_group DROP CONSTRAINT data_element_group_pkey;
ALTER TABLE ONLY public.boundary DROP CONSTRAINT boundary_pkey;
DROP TABLE public.translation;
DROP TABLE public.service_area_population;
DROP TABLE public.rmnchstats;
DROP TABLE public.rmnch;
DROP TABLE public.opddiagnostic;
DROP TABLE public.item_dimensions;
DROP TABLE public.item;
DROP SEQUENCE public.hibernate_sequence;
DROP TABLE public.facility_group_facilities;
DROP TABLE public.facility_group;
DROP TABLE public.facility_facility_groups;
DROP TABLE public.facility;
DROP TABLE public.dimension_items;
DROP TABLE public.dimension;
DROP TABLE public.diagnostic;
DROP TABLE public.databasechangeloglock;
DROP TABLE public.databasechangelog;
DROP TABLE public.data_element_translations;
DROP TABLE public.data_element_group;
DROP TABLE public.data_element;
DROP TABLE public.boundary;
DROP EXTENSION postgis;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: boundary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE boundary (
    dtype character varying(31) NOT NULL,
    gid bigint NOT NULL,
    geom geometry,
    name character varying(255),
    population bigint,
    population_female bigint,
    population_male bigint,
    shape_area bigint,
    shape_leng bigint,
    source character varying(255),
    areakm2 double precision,
    comments character varying(255),
    division character varying(255),
    pop bigint,
    pop_den double precision,
    population_rural bigint,
    population_rural_female bigint,
    population_rural_male bigint,
    population_urban bigint,
    population_urban_female bigint,
    population_urban_male bigint,
    "precision" integer,
    rural_fema bigint,
    ward_type character varying(255),
    region_gid bigint,
    district_gid bigint
);


ALTER TABLE boundary OWNER TO postgres;

--
-- Name: data_element; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE data_element (
    id bigint NOT NULL,
    dhis2id character varying(255),
    name character varying(255),
    data_element_group_id bigint
);


ALTER TABLE data_element OWNER TO postgres;

--
-- Name: data_element_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE data_element_group (
    id bigint NOT NULL,
    dhis2id character varying(255),
    name character varying(255)
);


ALTER TABLE data_element_group OWNER TO postgres;

--
-- Name: data_element_translations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE data_element_translations (
    data_element_id bigint NOT NULL,
    translations_id bigint NOT NULL
);


ALTER TABLE data_element_translations OWNER TO postgres;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE databasechangeloglock OWNER TO postgres;

--
-- Name: diagnostic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE diagnostic (
    id bigint NOT NULL,
    dhis2id character varying(255),
    name character varying(255)
);


ALTER TABLE diagnostic OWNER TO postgres;

--
-- Name: dimension; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE dimension (
    id bigint NOT NULL,
    dhis2id character varying(255),
    name character varying(255)
);


ALTER TABLE dimension OWNER TO postgres;

--
-- Name: dimension_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE dimension_items (
    dimension_id bigint NOT NULL,
    items_id bigint NOT NULL
);


ALTER TABLE dimension_items OWNER TO postgres;

--
-- Name: facility; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE facility (
    id bigint NOT NULL,
    code character varying(255),
    dhis2id character varying(255),
    dhis2parent_id character varying(255),
    name character varying(255),
    point geometry,
    detailed_ownership_id bigint,
    detailed_type_id bigint,
    ownership_id bigint,
    type_id bigint,
    ward_gid bigint
);


ALTER TABLE facility OWNER TO postgres;

--
-- Name: facility_facility_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE facility_facility_groups (
    facility_id bigint NOT NULL,
    facility_groups_id bigint NOT NULL
);


ALTER TABLE facility_facility_groups OWNER TO postgres;

--
-- Name: facility_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE facility_group (
    id bigint NOT NULL,
    dhis2id character varying(255),
    name character varying(255),
    item_id bigint
);


ALTER TABLE facility_group OWNER TO postgres;

--
-- Name: facility_group_facilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE facility_group_facilities (
    facility_group_id bigint NOT NULL,
    facilities_id bigint NOT NULL
);


ALTER TABLE facility_group_facilities OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hibernate_sequence OWNER TO postgres;

--
-- Name: item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE item (
    id bigint NOT NULL,
    dhis2id character varying(255),
    name character varying(255)
);


ALTER TABLE item OWNER TO postgres;

--
-- Name: item_dimensions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE item_dimensions (
    item_id bigint NOT NULL,
    dimensions_id bigint NOT NULL
);


ALTER TABLE item_dimensions OWNER TO postgres;

--
-- Name: opddiagnostic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE opddiagnostic (
    id bigint NOT NULL,
    month integer,
    quarter integer,
    value integer,
    year integer,
    age_id bigint,
    diagnostic_id bigint,
    facility_id bigint
);


ALTER TABLE opddiagnostic OWNER TO postgres;

--
-- Name: rmnch; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE rmnch (
    id bigint NOT NULL,
    month integer,
    quarter integer,
    value integer,
    year integer,
    facility_id bigint,
    indicator_id bigint
);


ALTER TABLE rmnch OWNER TO postgres;

--
-- Name: rmnchstats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE rmnchstats (
    id bigint NOT NULL,
    month integer,
    quarter integer,
    value integer,
    year integer,
    diagnostic_id bigint,
    facility_id bigint
);


ALTER TABLE rmnchstats OWNER TO postgres;

--
-- Name: service_area_population; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE service_area_population (
    id bigint NOT NULL,
    value double precision,
    year integer,
    age_id bigint,
    facility_id bigint,
    gender_id bigint
);


ALTER TABLE service_area_population OWNER TO postgres;

--
-- Name: translation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE translation (
    id bigint NOT NULL,
    key character varying(255),
    locale character varying(255),
    provided boolean NOT NULL,
    value character varying(255)
);


ALTER TABLE translation OWNER TO postgres;

--
-- Data for Name: boundary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY boundary (dtype, gid, geom, name, population, population_female, population_male, shape_area, shape_leng, source, areakm2, comments, division, pop, pop_den, population_rural, population_rural_female, population_rural_male, population_urban, population_urban_female, population_urban_male, "precision", rural_fema, ward_type, region_gid, district_gid) FROM stdin;
\.
COPY boundary (dtype, gid, geom, name, population, population_female, population_male, shape_area, shape_leng, source, areakm2, comments, division, pop, pop_den, population_rural, population_rural_female, population_rural_male, population_urban, population_urban_female, population_urban_male, "precision", rural_fema, ward_type, region_gid, district_gid) FROM '$$PATH$$/3693.dat';

--
-- Data for Name: data_element; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY data_element (id, dhis2id, name, data_element_group_id) FROM stdin;
\.
COPY data_element (id, dhis2id, name, data_element_group_id) FROM '$$PATH$$/3694.dat';

--
-- Data for Name: data_element_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY data_element_group (id, dhis2id, name) FROM stdin;
\.
COPY data_element_group (id, dhis2id, name) FROM '$$PATH$$/3696.dat';

--
-- Data for Name: data_element_translations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY data_element_translations (data_element_id, translations_id) FROM stdin;
\.
COPY data_element_translations (data_element_id, translations_id) FROM '$$PATH$$/3695.dat';

--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
\.
COPY databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM '$$PATH$$/3689.dat';

--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
\.
COPY databasechangeloglock (id, locked, lockgranted, lockedby) FROM '$$PATH$$/3688.dat';

--
-- Data for Name: diagnostic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY diagnostic (id, dhis2id, name) FROM stdin;
\.
COPY diagnostic (id, dhis2id, name) FROM '$$PATH$$/3690.dat';

--
-- Data for Name: dimension; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dimension (id, dhis2id, name) FROM stdin;
\.
COPY dimension (id, dhis2id, name) FROM '$$PATH$$/3697.dat';

--
-- Data for Name: dimension_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY dimension_items (dimension_id, items_id) FROM stdin;
\.
COPY dimension_items (dimension_id, items_id) FROM '$$PATH$$/3698.dat';

--
-- Data for Name: facility; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY facility (id, code, dhis2id, dhis2parent_id, name, point, detailed_ownership_id, detailed_type_id, ownership_id, type_id, ward_gid) FROM stdin;
\.
COPY facility (id, code, dhis2id, dhis2parent_id, name, point, detailed_ownership_id, detailed_type_id, ownership_id, type_id, ward_gid) FROM '$$PATH$$/3699.dat';

--
-- Data for Name: facility_facility_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY facility_facility_groups (facility_id, facility_groups_id) FROM stdin;
\.
COPY facility_facility_groups (facility_id, facility_groups_id) FROM '$$PATH$$/3700.dat';

--
-- Data for Name: facility_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY facility_group (id, dhis2id, name, item_id) FROM stdin;
\.
COPY facility_group (id, dhis2id, name, item_id) FROM '$$PATH$$/3701.dat';

--
-- Data for Name: facility_group_facilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY facility_group_facilities (facility_group_id, facilities_id) FROM stdin;
\.
COPY facility_group_facilities (facility_group_id, facilities_id) FROM '$$PATH$$/3702.dat';

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 2583032, true);


--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY item (id, dhis2id, name) FROM stdin;
\.
COPY item (id, dhis2id, name) FROM '$$PATH$$/3703.dat';

--
-- Data for Name: item_dimensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY item_dimensions (item_id, dimensions_id) FROM stdin;
\.
COPY item_dimensions (item_id, dimensions_id) FROM '$$PATH$$/3704.dat';

--
-- Data for Name: opddiagnostic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY opddiagnostic (id, month, quarter, value, year, age_id, diagnostic_id, facility_id) FROM stdin;
\.
COPY opddiagnostic (id, month, quarter, value, year, age_id, diagnostic_id, facility_id) FROM '$$PATH$$/3705.dat';

--
-- Data for Name: rmnch; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY rmnch (id, month, quarter, value, year, facility_id, indicator_id) FROM stdin;
\.
COPY rmnch (id, month, quarter, value, year, facility_id, indicator_id) FROM '$$PATH$$/3706.dat';

--
-- Data for Name: rmnchstats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY rmnchstats (id, month, quarter, value, year, diagnostic_id, facility_id) FROM stdin;
\.
COPY rmnchstats (id, month, quarter, value, year, diagnostic_id, facility_id) FROM '$$PATH$$/3691.dat';

--
-- Data for Name: service_area_population; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY service_area_population (id, value, year, age_id, facility_id, gender_id) FROM stdin;
\.
COPY service_area_population (id, value, year, age_id, facility_id, gender_id) FROM '$$PATH$$/3707.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/3505.dat';

--
-- Data for Name: translation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY translation (id, key, locale, provided, value) FROM stdin;
\.
COPY translation (id, key, locale, provided, value) FROM '$$PATH$$/3708.dat';

--
-- Name: boundary boundary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY boundary
    ADD CONSTRAINT boundary_pkey PRIMARY KEY (gid);


--
-- Name: data_element_group data_element_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_element_group
    ADD CONSTRAINT data_element_group_pkey PRIMARY KEY (id);


--
-- Name: data_element data_element_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_element
    ADD CONSTRAINT data_element_pkey PRIMARY KEY (id);


--
-- Name: diagnostic diagnostic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY diagnostic
    ADD CONSTRAINT diagnostic_pkey PRIMARY KEY (id);


--
-- Name: dimension dimension_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dimension
    ADD CONSTRAINT dimension_pkey PRIMARY KEY (id);


--
-- Name: facility_group facility_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility_group
    ADD CONSTRAINT facility_group_pkey PRIMARY KEY (id);


--
-- Name: facility facility_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility
    ADD CONSTRAINT facility_pkey PRIMARY KEY (id);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY item
    ADD CONSTRAINT item_pkey PRIMARY KEY (id);


--
-- Name: opddiagnostic opddiagnostic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY opddiagnostic
    ADD CONSTRAINT opddiagnostic_pkey PRIMARY KEY (id);


--
-- Name: databasechangeloglock pk_databasechangeloglock; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY databasechangeloglock
    ADD CONSTRAINT pk_databasechangeloglock PRIMARY KEY (id);


--
-- Name: rmnch rmnch_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rmnch
    ADD CONSTRAINT rmnch_pkey PRIMARY KEY (id);


--
-- Name: rmnchstats rmnchstats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rmnchstats
    ADD CONSTRAINT rmnchstats_pkey PRIMARY KEY (id);


--
-- Name: service_area_population service_area_population_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY service_area_population
    ADD CONSTRAINT service_area_population_pkey PRIMARY KEY (id);


--
-- Name: translation translation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY translation
    ADD CONSTRAINT translation_pkey PRIMARY KEY (id);


--
-- Name: data_element_translations uk_gb0cioki60jj0og226wg818d6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_element_translations
    ADD CONSTRAINT uk_gb0cioki60jj0og226wg818d6 UNIQUE (translations_id);


--
-- Name: data_element_translations fk2dw0wq479f3bdsbuhb5hfq231; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_element_translations
    ADD CONSTRAINT fk2dw0wq479f3bdsbuhb5hfq231 FOREIGN KEY (data_element_id) REFERENCES data_element(id);


--
-- Name: service_area_population fk2v9tam2oiy4qe75ekv8ms17aa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY service_area_population
    ADD CONSTRAINT fk2v9tam2oiy4qe75ekv8ms17aa FOREIGN KEY (gender_id) REFERENCES item(id);


--
-- Name: facility_facility_groups fk2weac2drtkoy9n5os5wputc4q; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility_facility_groups
    ADD CONSTRAINT fk2weac2drtkoy9n5os5wputc4q FOREIGN KEY (facility_id) REFERENCES facility(id);


--
-- Name: facility fk5wog9901mp0tqel6i1akhwtk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility
    ADD CONSTRAINT fk5wog9901mp0tqel6i1akhwtk FOREIGN KEY (detailed_type_id) REFERENCES item(id);


--
-- Name: service_area_population fk6dyn82rhv6lsxm5qu7ov8bqgu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY service_area_population
    ADD CONSTRAINT fk6dyn82rhv6lsxm5qu7ov8bqgu FOREIGN KEY (age_id) REFERENCES item(id);


--
-- Name: dimension_items fk72sdctk51y84wcqntmjfdlpe9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dimension_items
    ADD CONSTRAINT fk72sdctk51y84wcqntmjfdlpe9 FOREIGN KEY (dimension_id) REFERENCES dimension(id);


--
-- Name: opddiagnostic fk8ca17o9vx5wbhi6kpiwt3088q; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY opddiagnostic
    ADD CONSTRAINT fk8ca17o9vx5wbhi6kpiwt3088q FOREIGN KEY (age_id) REFERENCES item(id);


--
-- Name: facility fk8j57byit1jvb12yh4fg0yr5ks; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility
    ADD CONSTRAINT fk8j57byit1jvb12yh4fg0yr5ks FOREIGN KEY (detailed_ownership_id) REFERENCES item(id);


--
-- Name: opddiagnostic fk9apomeehpcrljyg2g5qc0mndu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY opddiagnostic
    ADD CONSTRAINT fk9apomeehpcrljyg2g5qc0mndu FOREIGN KEY (diagnostic_id) REFERENCES data_element(id);


--
-- Name: boundary fkaimesq4gtk0iuawas0vqr6rhn; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY boundary
    ADD CONSTRAINT fkaimesq4gtk0iuawas0vqr6rhn FOREIGN KEY (region_gid) REFERENCES boundary(gid);


--
-- Name: facility fkdet2sgl9my09fk9ln00lbdes7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility
    ADD CONSTRAINT fkdet2sgl9my09fk9ln00lbdes7 FOREIGN KEY (ward_gid) REFERENCES boundary(gid);


--
-- Name: data_element fkdx8fglnnrtktmbydu7rclq3ve; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_element
    ADD CONSTRAINT fkdx8fglnnrtktmbydu7rclq3ve FOREIGN KEY (data_element_group_id) REFERENCES data_element_group(id);


--
-- Name: dimension_items fke1a11lrwnmr0vjk6h5oopk75f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY dimension_items
    ADD CONSTRAINT fke1a11lrwnmr0vjk6h5oopk75f FOREIGN KEY (items_id) REFERENCES item(id);


--
-- Name: facility_group fke8jxd3iytlrbitpxhfg8p79x7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility_group
    ADD CONSTRAINT fke8jxd3iytlrbitpxhfg8p79x7 FOREIGN KEY (item_id) REFERENCES item(id);


--
-- Name: service_area_population fkecnnrgvhq7lk2ca2bmlbl9cer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY service_area_population
    ADD CONSTRAINT fkecnnrgvhq7lk2ca2bmlbl9cer FOREIGN KEY (facility_id) REFERENCES facility(id);


--
-- Name: facility fkf8c50o6a6erfkx1hj3i8ba8sk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility
    ADD CONSTRAINT fkf8c50o6a6erfkx1hj3i8ba8sk FOREIGN KEY (type_id) REFERENCES item(id);


--
-- Name: opddiagnostic fki4gkh4hr3jcikll8vxahc6l7e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY opddiagnostic
    ADD CONSTRAINT fki4gkh4hr3jcikll8vxahc6l7e FOREIGN KEY (facility_id) REFERENCES facility(id);


--
-- Name: item_dimensions fkkulucw5lwr46hkysg5l9wlxn2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY item_dimensions
    ADD CONSTRAINT fkkulucw5lwr46hkysg5l9wlxn2 FOREIGN KEY (dimensions_id) REFERENCES dimension(id);


--
-- Name: rmnch fkkw8h9d9wcsxnomq2eoawxqkt9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rmnch
    ADD CONSTRAINT fkkw8h9d9wcsxnomq2eoawxqkt9 FOREIGN KEY (indicator_id) REFERENCES data_element(id);


--
-- Name: facility_group_facilities fkl3tirh1uljkf3xhrf2j4puqje; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility_group_facilities
    ADD CONSTRAINT fkl3tirh1uljkf3xhrf2j4puqje FOREIGN KEY (facility_group_id) REFERENCES facility_group(id);


--
-- Name: boundary fklvt5hl8xv3jbl8kd7y1jd3yxv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY boundary
    ADD CONSTRAINT fklvt5hl8xv3jbl8kd7y1jd3yxv FOREIGN KEY (district_gid) REFERENCES boundary(gid);


--
-- Name: facility_group_facilities fklwwtfhcmvqa3v7xursbgsua61; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility_group_facilities
    ADD CONSTRAINT fklwwtfhcmvqa3v7xursbgsua61 FOREIGN KEY (facilities_id) REFERENCES facility(id);


--
-- Name: rmnch fkmen00wrqnjf8e6dm8r3quwu4g; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rmnch
    ADD CONSTRAINT fkmen00wrqnjf8e6dm8r3quwu4g FOREIGN KEY (facility_id) REFERENCES facility(id);


--
-- Name: data_element_translations fkmsvxxu81ayetxxwryvyd18l7o; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY data_element_translations
    ADD CONSTRAINT fkmsvxxu81ayetxxwryvyd18l7o FOREIGN KEY (translations_id) REFERENCES translation(id);


--
-- Name: facility_facility_groups fko4fakdwhwkcsje3p6icvgj3qr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility_facility_groups
    ADD CONSTRAINT fko4fakdwhwkcsje3p6icvgj3qr FOREIGN KEY (facility_groups_id) REFERENCES facility_group(id);


--
-- Name: facility fkrf62o3y7km7j0v3v3axinjt0v; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY facility
    ADD CONSTRAINT fkrf62o3y7km7j0v3v3axinjt0v FOREIGN KEY (ownership_id) REFERENCES item(id);


--
-- Name: item_dimensions fksnh7d3p4udcppsfspjhsbta6q; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY item_dimensions
    ADD CONSTRAINT fksnh7d3p4udcppsfspjhsbta6q FOREIGN KEY (item_id) REFERENCES item(id);


--
-- PostgreSQL database dump complete
--

